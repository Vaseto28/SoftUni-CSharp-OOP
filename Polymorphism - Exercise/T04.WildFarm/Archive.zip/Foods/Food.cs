﻿using System;
namespace T04.WildFarm
{
    public abstract class Food
    {
        public int Quantity { get; set; }
    }
}

