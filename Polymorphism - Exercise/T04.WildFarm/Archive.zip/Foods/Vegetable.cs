﻿using System;
namespace T04.WildFarm
{
    public class Vegetable : Food
    {

    }
}

