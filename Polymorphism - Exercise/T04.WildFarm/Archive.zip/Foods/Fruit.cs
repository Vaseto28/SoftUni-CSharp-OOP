﻿using System;
namespace T04.WildFarm.Foods
{
    public class Fruit : Food
    {

    }
}

