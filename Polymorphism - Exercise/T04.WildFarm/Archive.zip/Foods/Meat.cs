﻿using System;
namespace T04.WildFarm.Foods
{
    public class Meat : Food
    {

    }
}

