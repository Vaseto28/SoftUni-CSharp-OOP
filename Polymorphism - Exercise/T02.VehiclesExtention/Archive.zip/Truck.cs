using System;

namespace T02.VehiclesExtention
{
    public class Truck : Vehicle
    {
        public Truck(double fuelQuantity, double fuelConsumption, double tankCapacity) : base(fuelQuantity, fuelConsumption, tankCapacity)
        {
        }

        public override bool Refuel(double litres)
        {
            double refueledLitres = 0.95 * litres;
            this.FuelQuantity += refueledLitres;

            if (this.FuelQuantity > this.TankCapacity)
            {
                this.FuelQuantity -= refueledLitres;
                return false;
            }

            return true;
        }
    }
}

