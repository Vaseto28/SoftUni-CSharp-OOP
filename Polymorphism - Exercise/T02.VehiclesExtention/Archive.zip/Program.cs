namespace T02.VehiclesExtention
{
    using System;

    class Program
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string[] truckInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string[] busInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

            double carFuelQuantity = double.Parse(carInfo[1]);
            double carFuelConsumption = double.Parse(carInfo[2]) + 0.9;
            double carTankCapacity = double.Parse(carInfo[3]);

            double truckFuelQuantity = double.Parse(truckInfo[1]);
            double truckFuelConsumption = double.Parse(truckInfo[2]) + 1.6;
            double truckTankCapacity = double.Parse(truckInfo[3]);

            double busFuelQuantity = double.Parse(busInfo[1]);
            double busFuelConsumption = double.Parse(busInfo[2]);
            double busTankCapacity = double.Parse(busInfo[3]);

            Car car = new Car(carFuelQuantity, carFuelConsumption, carTankCapacity);
            Truck truck = new Truck(truckFuelQuantity, truckFuelConsumption, truckTankCapacity);
            Bus bus = new Bus(busFuelQuantity, busFuelConsumption, busTankCapacity);

            if (carFuelQuantity > carTankCapacity)
            {
                car.FuelQuantity= 0;
            }

            if (truckFuelQuantity > truckTankCapacity)
            {
                truck.FuelQuantity = 0;
            }

            if (busFuelQuantity > busTankCapacity)
            {
                bus.FuelQuantity = 0;
            }

            int commandsCnt = int.Parse(Console.ReadLine());
            for (int i = 0; i < commandsCnt; i++)
            {
                string[] commandInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                string action = commandInfo[0];
                string vehicleType = commandInfo[1];


                if (action == "Drive")
                {
                    double distance = double.Parse(commandInfo[2]);

                    if (vehicleType == "Car")
                    {
                        if (car.Drive(distance))
                        {
                            Console.WriteLine($"Car travelled {distance} km");
                        }
                        else
                        {
                            Console.WriteLine($"Car needs refueling");
                        }
                    }
                    else if (vehicleType == "Truck")
                    {
                        if (truck.Drive(distance))
                        {
                            Console.WriteLine($"Truck travelled {distance} km");
                        }
                        else
                        {
                            Console.WriteLine($"Truck needs refueling");
                        }
                    }
                    else if (vehicleType == "Bus")
                    {
                        if (bus.DriveNotEmpty(distance))
                        {
                            Console.WriteLine($"Bus travelled {distance} km");
                        }
                        else
                        {
                            Console.WriteLine($"Bus needs refueling");
                        }
                    }
                }
                else if (action == "Refuel")
                {
                    double litres = double.Parse(commandInfo[2]);

                    if (litres > 0)
                    {
                        if (vehicleType == "Car")
                        {
                            if (!car.Refuel(litres))
                            {
                                Console.WriteLine($"Cannot fit {litres} fuel in the tank");
                            }
                        }
                        else if (vehicleType == "Truck")
                        {
                            if (!truck.Refuel(litres))
                            {
                                Console.WriteLine($"Cannot fit {litres} fuel in the tank");
                            }
                        }
                        else if (vehicleType == "Bus")
                        {
                            if (!bus.Refuel(litres))
                            {
                                Console.WriteLine($"Cannot fit {litres} fuel in the tank");
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("Fuel must be a positive number");
                    }
                }
                else if (action == "DriveEmpty")
                {
                    double distance = double.Parse(commandInfo[2]);
                    if (bus.Drive(distance))
                    {
                        Console.WriteLine($"Bus travelled {distance} km");
                    }
                    else
                    {
                        Console.WriteLine($"Bus needs refueling");
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
            Console.WriteLine($"Bus: {bus.FuelQuantity:f2}");
        }
    }
}

