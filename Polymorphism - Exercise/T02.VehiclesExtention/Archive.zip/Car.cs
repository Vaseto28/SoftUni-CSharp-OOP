using System;
namespace T02.VehiclesExtention
{
    public class Car : Vehicle
    {
        public Car(double fuelQuantity, double fuelConsumption, double tankCapacity) : base(fuelQuantity, fuelConsumption, tankCapacity)
        {
        }

        public override bool Refuel(double litres)
        {
            this.FuelQuantity += litres;

            if (this.FuelQuantity > this.TankCapacity)
            {
                this.FuelQuantity -= litres;
                return false;
            }

            return true;
        }
    }
}

