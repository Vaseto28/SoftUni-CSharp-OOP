namespace T01.Vehicles
{
    using System;

    class Program
    {
        static void Main(string[] args)
        {
            string[] carInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
            string[] truckInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);

            double carFuelQuantity = double.Parse(carInfo[1]);
            double carFuelConsumption = double.Parse(carInfo[2]) + 0.9;

            double truckFuelQuantity = double.Parse(truckInfo[1]);
            double truckFuelConsumption = double.Parse(truckInfo[2]) + 1.6;

            Car car = new Car(carFuelQuantity, carFuelConsumption);
            Truck truck = new Truck(truckFuelQuantity, truckFuelConsumption);

            int commandsCnt = int.Parse(Console.ReadLine());
            for (int i = 0; i < commandsCnt; i++)
            {
                string[] commandInfo = Console.ReadLine().Split(' ', StringSplitOptions.RemoveEmptyEntries);
                string action = commandInfo[0];
                string vehicleType = commandInfo[1];


                if (action == "Drive")
                {
                    double distance = double.Parse(commandInfo[2]);

                    if (vehicleType == "Car")
                    {
                        if (car.Drive(distance))
                        {
                            Console.WriteLine($"Car travelled {distance} km");
                        }
                        else
                        {
                            Console.WriteLine($"Car needs refueling");
                        }
                    }
                    else if (vehicleType == "Truck")
                    {
                        if (truck.Drive(distance))
                        {
                            Console.WriteLine($"Truck travelled {distance} km");
                        }
                        else
                        {
                            Console.WriteLine($"Truck needs refueling");
                        }
                    }
                }
                else if (action == "Refuel")
                {
                    double litres = double.Parse(commandInfo[2]);

                    if (vehicleType == "Car")
                    {
                        car.Refuel(litres);
                    }
                    else if (vehicleType == "Truck")
                    {
                        truck.Refuel(litres);
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
        }
    }
}

