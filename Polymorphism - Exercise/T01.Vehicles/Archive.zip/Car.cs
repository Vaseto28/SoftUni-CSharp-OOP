using System;
namespace T01.Vehicles
{
    public class Car
    {
        public double FuelQuantity { get; set; }

        public double FuelConsumption { get; set; }

        public Car(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public bool Drive(double distance)
        {
            double neededLitres = this.FuelConsumption * distance;

            if (this.FuelQuantity >= neededLitres)
            {
                this.FuelQuantity -= neededLitres;
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Refuel(double fuel)
        {
            this.FuelQuantity += fuel;
        }
    }
}

