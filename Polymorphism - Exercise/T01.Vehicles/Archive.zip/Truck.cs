using System;
namespace T01.Vehicles
{
    public class Truck
    {
        public double FuelQuantity { get; set; }

        public double FuelConsumption { get; set; }

        public Truck(double fuelQuantity, double fuelConsumption)
        {
            this.FuelQuantity = fuelQuantity;
            this.FuelConsumption = fuelConsumption;
        }

        public bool Drive(double distance)
        {
            double neededLitres = this.FuelConsumption * distance;

            if (this.FuelQuantity >= neededLitres)
            {
                this.FuelQuantity -= neededLitres;
                return true;
            }
            else
            {
                return false;
            }
        }

        public void Refuel(double litres)
        {
            double refueledLitres = 0.95 * litres;
            this.FuelQuantity += refueledLitres;
        }
    }
}

