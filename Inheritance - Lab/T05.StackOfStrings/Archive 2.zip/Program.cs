﻿using System;

namespace CustomStack
{
    class StartUp
    {
        public static void Main(string[] args)
        {

        }
    }
}